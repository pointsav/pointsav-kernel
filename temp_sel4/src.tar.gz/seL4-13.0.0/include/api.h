/*
 * Copyright 2014, General Dynamics C4 Systems
 *
 * SPDX-License-Identifier: GPL-2.0-only
 */

#pragma once

#include <api/types.h>
#include <api/failures.h>
#include <api/syscall.h>
