/*
 * Copyright 2022, HENSOLDT Cyber
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#pragma once

#include <sel4/config.h>

/* nothing here */
