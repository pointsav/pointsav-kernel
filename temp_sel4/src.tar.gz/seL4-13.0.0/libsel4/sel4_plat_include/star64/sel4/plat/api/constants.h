/*
 * Copyright 2023, Ivan Velickovic
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#pragma once

#include <sel4/config.h>
