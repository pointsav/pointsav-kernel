<!--
     Copyright 2021, seL4 Project a Series of LF Projects, LLC

     SPDX-License-Identifier: CC-BY-SA-4.0
-->

seL4 Reference Manual
=====================

To build a PDF use

    make

You will need recent version of `LaTeX` and `doxygen`.

The main source file is `manual.tex`, most of the text is in `parts/`,
and most of the API reference is generated with `doxygen`.
